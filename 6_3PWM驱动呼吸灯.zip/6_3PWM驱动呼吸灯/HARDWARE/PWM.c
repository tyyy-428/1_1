#include "stm32f10x.h"                  // Device header

void PWM_Init(void)
{

RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
 
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//开启时钟
	
	//配置端口模式
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);

	TIM_InternalClockConfig(TIM2);//上电后默认内部时钟
	
	//配置时基单元
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStrcture;
	TIM_TimeBaseInitStrcture.TIM_ClockDivision = TIM_CKD_DIV1;//跟时基单元关系不大，用与滤波器参数选择
	TIM_TimeBaseInitStrcture.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStrcture.TIM_Period = 99;//ARR
	TIM_TimeBaseInitStrcture.TIM_Prescaler = 720-1;//PSC
	TIM_TimeBaseInitStrcture.TIM_RepetitionCounter  = 0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStrcture);
	

    TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OCPolarity  = TIM_OCPolarity_High;//极性
	TIM_OCInitStructure.TIM_OutputState  = ENABLE;//使能状态
	TIM_OCInitStructure.TIM_Pulse = 0;//设置CCR
	TIM_OC1Init(TIM2,&TIM_OCInitStructure);

	TIM_Cmd(TIM2,ENABLE);

}

void PWM_SETCOMPARE1(uint16_t Compare)
{
    TIM_SetCompare1(TIM2,Compare);
    
}
