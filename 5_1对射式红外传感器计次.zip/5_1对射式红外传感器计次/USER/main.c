#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "OLED.h"
#include  "COUNTSENSOR.h"


int main(void)
{
	 OLED_Init();
	 COUNTSENSOR_Init();
	
	OLED_ShowString(1,3,"COUNT:");
      	
while(1)
{
     OLED_ShowNum(2,1,COUNTSENSOR_GET(),5);
}

}
