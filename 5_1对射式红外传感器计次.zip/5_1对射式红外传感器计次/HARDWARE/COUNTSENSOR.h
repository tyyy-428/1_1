#ifndef  __COUNTSENSOR_H
#define  __COUNTSENSOR_H

void COUNTSENSOR_Init(void);
uint16_t COUNTSENSOR_GET();




#endif
