#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "OLED.h"

uint8_t KeyNum = 0;

int main(void)
{
	 OLED_Init();
	OLED_ShowChar(1,1,'B');
	OLED_ShowString(1,3,"HELLO WORLD!");
      	
while(1)
{
     
}

}
