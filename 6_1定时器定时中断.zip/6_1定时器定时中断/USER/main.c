#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "OLED.h"
#include  "TIMER.h"

 

uint16_t Num = 0;

int main(void)
{
	OLED_Init();
	TIMER_Init();
	OLED_ShowChar(1,1,'B');
	OLED_ShowString(1,3,"NUM:");
      	
while(1)
{
   OLED_ShowNum(2,1,Num,5);  
}






}
