#include "stm32f10x.h"                  // Device header

extern uint16_t Num;

void TIMER_Init(void)
{

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	TIM_InternalClockConfig(TIM2);//上电后默认内部时钟
	
	//配置时基单元
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStrcture;
	TIM_TimeBaseInitStrcture.TIM_ClockDivision = TIM_CKD_DIV1;//跟时基单元关系不大，用与滤波器参数选择
	TIM_TimeBaseInitStrcture.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStrcture.TIM_Period = 10000-1;
	TIM_TimeBaseInitStrcture.TIM_Prescaler = 7200-1;
	TIM_TimeBaseInitStrcture.TIM_RepetitionCounter  = 0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStrcture);
	 
	TIM_ClearFlag(TIM2,TIM_FLAG_Update);//为了解决一开始就进入中断更新事件
	
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);//开启了更新中断到NVIC的通路
	
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//??
	
	NVIC_InitTypeDef  NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority  = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1 ;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM2,ENABLE);
	
}

void TIM2_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)
	{
	Num ++;
	
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	}

}

