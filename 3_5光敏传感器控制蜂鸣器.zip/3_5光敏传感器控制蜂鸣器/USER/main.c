#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "BUZZER.h"
#include  "LIGHTSENSOR.h"



int main(void)
{
    LIGHTSENSOR();
	BUZZER_Init();
    	
while(1)
{

    if(LIGHTSENSOR_GET() == 1)
	   BUZZER_ON();
	else
		BUZZER_OFF();
	
}

}
