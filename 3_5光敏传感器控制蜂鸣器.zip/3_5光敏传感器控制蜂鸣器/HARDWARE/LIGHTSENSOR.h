#ifndef __LIGHTSENSOR_H
#define __LIGHTSENSOR_H

uint8_t LIGHTSENSOR_GET(void);
void LIGHTSENSOR(void);

#endif