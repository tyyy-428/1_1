#ifndef  __ENCODER_H
#define  __ENCODER_H

int16_t ENCODER_GET(void);
void ENCODER_Init(void);


#endif