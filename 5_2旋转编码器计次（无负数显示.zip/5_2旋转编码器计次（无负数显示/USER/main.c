#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "OLED.h"
#include  "ENCODER.h"

int16_t Num = 100;

int main(void)
{
	 OLED_Init();
	 ENCODER_Init();
	
	
	OLED_ShowString(1,3,"COUNT:");
      	
while(1)
{
    Num += ENCODER_GET();  
	OLED_ShowNum(3,1,Num,5);
}

}
