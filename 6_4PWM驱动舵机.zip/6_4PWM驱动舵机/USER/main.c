#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "OLED.h"
#include  "SERVO.h"
#include  "KEY.h"


uint8_t KeyNum;
float Angle;

int main(void)
{
    OLED_Init();
	SERVO_Init();
    KEY_Init();
	
    OLED_ShowString(1,1,"ANGLE:");     
 	
while(1)
{
    KeyNum = KEY_GetNum();
	if(KeyNum == 1)
	{
	    Angle += 30;
		if(Angle > 180)
		{
		Angle = 0;
		
		}
	}
	SERVO_SETANGLE(Angle);
		OLED_ShowNum(2,1,Angle,3);
}

}
