#include "stm32f10x.h"                  // Device header
#include "PWM.h"  

void SERVO_Init(void)
{
    PWM_Init();
	
}

void SERVO_SETANGLE(float Angle)
{
 
    PWM_SETCOMPARE2( Angle / 180 * 2000 + 500);

}
