#ifndef  __SERV0_H
#define  __SERVO_H

void SERVO_Init(void);
void SERVO_SETANGLE(float ANGLE);

#endif
