#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "OLED.h"
#include  "TIMER.h"

 

uint16_t Num = 0;

int main(void)
{
	OLED_Init();
	TIMER_Init();
	
	OLED_ShowString(1,3,"NUM:");
	OLED_ShowString(3,3,"CNT:");
      	
while(1)
{
   OLED_ShowNum(2,1,Num,5);  
	OLED_ShowNum(4,1,Timer_GetCounter(),5);

}






}
