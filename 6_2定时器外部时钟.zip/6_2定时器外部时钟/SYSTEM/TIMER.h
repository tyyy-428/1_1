#ifndef  __TIMER_H
#define  __TIMER_H

void TIMER_Init(void);
uint16_t Timer_GetCounter(void);

#endif
