#include "stm32f10x.h"                  // Device header
#include  "Delay.h"
#include  "OLED.h"
#include  "PWM.h"

uint8_t i;

int main(void)
{
    OLED_Init();
	PWM_Init();
	IC_Init();
	
	OLED_ShowString(1,1,"FREQ:00000Hz");
	OLED_ShowString(2,1,"DUTY:00%");

    PWM_SetPrescaler(720 - 1);      //Freq = 72k / ( PSC + 1 ) / 100
    PWM_SETCOMPARE1(50);            //Duty = CCR / 100	
while(1)
{
    OLED_ShowNum(1,6,IC_GetFreq(),5);
	 OLED_ShowNum(2,6,IC_GetDuty(),2);
}

}
